import { connectToDatabase } from '@/lib/mongodb';
import UserModel from '@/lib/models/User';
import { AppUser } from '@/types';
import AddUserForm from '@/components/AddUserForm';
import AdminUserRow from '@/components/AdminUserRow';
import { getSessionUser } from '@/lib/serverAuth';
import { canManageUsers } from '@/lib/permissions';
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

async function getUsers(): Promise<AppUser[]> {
  await connectToDatabase();
  const users = await UserModel.find().sort({ createdAt: -1 }).lean();
  return JSON.parse(JSON.stringify(users));
}

export default async function AdminUsersPage() {
  const sessionUser = await getSessionUser();
  if (!sessionUser || !canManageUsers(sessionUser)) {
    redirect('/admin/products');
  }

  const users = await getUsers();

  return (
    <div>
      <h1 className="mb-5 text-xl font-extrabold text-navy">Users ({users.length})</h1>
      <AddUserForm />
      <div className="overflow-x-auto rounded-xl2 border border-border bg-white p-4">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-border text-xs uppercase text-muted">
              <th className="pb-2 pr-3">Name</th>
              <th className="pb-2 pr-3">Phone</th>
              <th className="pb-2 pr-3">Role</th>
              <th className="pb-2 pr-3">Status</th>
              <th className="pb-2 pr-3">Wallet</th>
              <th className="pb-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <AdminUserRow key={user._id} user={user} currentUserId={sessionUser.id} />
            ))}
          </tbody>
        </table>
        {users.length === 0 && <p className="py-6 text-center text-muted">No users yet.</p>}
      </div>
    </div>
  );
}
